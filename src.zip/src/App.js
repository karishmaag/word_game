
import './App.css';
import Word_game from './components/Word_game';

function App() {
  return (
    <div className="App">
      <Word_game/>
    </div>
  );
}

export default App;
